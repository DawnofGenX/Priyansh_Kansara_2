var content='<div class="ui-page " deviceName="iphone16promax" deviceType="mobile" deviceWidth="440" deviceHeight="956">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS iphone-device canvas firer commentable non-processed" alignment="left" name="Template 1"width="440" height="956">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/templates/f39803f7-df02-4169-93eb-7547fb8c961a/style-1738230134512.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-7fdbe31e-d2d2-4521-a3e1-dfaf18e423be" class="screen growth-vertical devMobile devIOS iphone-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Add_Classroom"width="440" height="956">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/screens/7fdbe31e-d2d2-4521-a3e1-dfaf18e423be/style-1738230134512.css" />\
      <link type="text/css" rel="stylesheet" href="./review/screens/7fdbe31e-d2d2-4521-a3e1-dfaf18e423be/fonts-1738230134512.css" />\
      <div class="freeLayout">\
      <div id="s-Button_1" class="button multiline manualfit firer click commentable non-processed" customid="Filled button"   datasizewidth="355.27px" datasizeheight="50.00px" dataX="42.98" dataY="125.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_1_0">Name your Classroom</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_2" class="button multiline manualfit firer click commentable non-processed" customid="Filled button"   datasizewidth="355.27px" datasizeheight="50.00px" dataX="41.75" dataY="265.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_2_0">Name the Subject</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_3" class="button multiline manualfit firer click commentable non-processed" customid="Filled button"   datasizewidth="355.27px" datasizeheight="50.00px" dataX="42.17" dataY="410.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_3_0">Number of Students</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Group_19" class="group firer ie-background commentable non-processed" customid="Input field" datasizewidth="0.00px" datasizeheight="0.00px" >\
        <div id="s-Input_17" class="text firer focusin focusout commentable non-processed" customid="Dialog input"  datasizewidth="355.27px" datasizeheight="40.00px" dataX="42.98" dataY="201.07" ><div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Label"/></div></div>  </div></div></div>\
        <div id="s-Subtraction_5" class="path firer click commentable hidden non-processed" customid="Cancel icon"   datasizewidth="18.00px" datasizeheight="18.00px" dataX="372.49" dataY="212.07"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="18.0" height="17.999819967310998" viewBox="372.4925684878392 212.0743987073731 18.0 17.999819967310998" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Subtraction_5-7fdbe" d="M378.7505083906597 217.9150615994889 C378.85070769476005 217.9150615994889 378.95098190489404 217.95306836450385 379.0274110277079 218.029168894977 L381.4896971911439 220.485999265919 L383.9575264010563 218.029168894977 C384.0338806178366 217.95314293631233 384.13405495325935 217.91513617129732 384.234229288682 217.91513617129732 C384.33437865542675 217.91513617129732 384.4345280221716 217.95314293631233 384.51090720762977 218.029168894977 C384.6630912989561 218.18067395237824 384.6636406098681 218.42802864084413 384.51090720762977 218.58008055817356 L382.04252868680516 221.03745778904383 L384.5048398189189 223.49538187984234 C384.65699894156745 223.64688693724358 384.65757322115735 223.89424162570936 384.504265539329 224.04574668311056 C384.427886353871 224.12177264177538 384.3277369871261 224.15977940679034 384.22758762038126 224.15977940679034 C384.1274132849586 224.15977940679034 384.02723894953596 224.12177264177538 383.9508847327557 224.04574668311056 L381.48914788023177 221.58836945224036 L379.0274110277079 224.03913464943236 C378.95110674828317 224.1150860362887 378.8509074441828 224.1529685149564 378.75078304611566 224.1529685149564 C378.65045889862625 224.1529685149564 378.55018468849215 224.11494932130668 378.47403022113457 224.03913464943236 C378.32129681889614 223.88708273210293 378.32129681889614 223.64027490356537 378.47403022113457 223.48822298623583 L380.93631638457055 221.03691092911555 L378.47345594154444 218.57953369824529 C378.32129681889614 218.42693492098758 378.32129681889614 218.18011466381526 378.47457953204656 218.02862203504876 C378.55060915601507 217.95293164952184 378.65050883598167 217.9150615994889 378.7505083906597 217.9150615994889 Z M381.49259355777116 212.0743987073731 C376.5430775217548 212.0743987073731 372.4704864195319 216.14217899793067 372.4926586054379 221.0743086910286 C372.4705613255652 225.9894857263501 376.5151126025939 230.05215784803218 381.45231908044406 230.074131674241 C381.46575222911235 230.07419381741462 381.4791604091029 230.0742186746841 381.49256858909337 230.0742186746841 C386.442059656432 230.0742186746841 390.5146257899772 226.0064259554918 390.49247857274884 221.0743086910286 C390.5145508839437 216.15913165570714 386.4700245755929 212.0964719626598 381.53281809774273 212.07448570781625 C381.5194099177521 212.07442356464256 381.5060017377618 212.0743987073731 381.49259355777116 212.0743987073731 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Subtraction_5-7fdbe" fill="#8E8E93" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Group_20" class="group firer ie-background commentable non-processed" customid="Input field" datasizewidth="0.00px" datasizeheight="0.00px" >\
        <div id="s-Input_18" class="text firer focusin focusout commentable non-processed" customid="Dialog input"  datasizewidth="355.27px" datasizeheight="40.00px" dataX="42.75" dataY="349.25" ><div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Label"/></div></div>  </div></div></div>\
        <div id="s-Subtraction_6" class="path firer click commentable hidden non-processed" customid="Cancel icon"   datasizewidth="18.00px" datasizeheight="18.00px" dataX="372.27" dataY="360.25"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="18.000000000000227" height="17.999819967310827" viewBox="372.26748252688355 360.2543508826647 18.000000000000227 17.999819967310827" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Subtraction_6-7fdbe" d="M378.5254224297042 366.09501377478045 C378.6256217338045 366.09501377478045 378.7258959439385 366.13302053979544 378.80232506675236 366.20912107026857 L381.26461123018834 368.66595144121055 L383.7324404401009 366.20912107026857 C383.80879465688116 366.1330951116039 383.9089689923039 366.0950883465889 384.0091433277266 366.0950883465889 C384.1092926944713 366.0950883465889 384.2094420612162 366.1330951116039 384.28582124667435 366.20912107026857 C384.43800533800066 366.3606261276698 384.43855464891266 366.6079808161357 384.28582124667435 366.7600327334651 L381.8174427258497 369.2174099643354 L384.2797538579635 371.6753340551339 C384.431912980612 371.82683911253514 384.4324872602019 372.0741938010009 384.2791795783736 372.2256988584021 C384.20280039291555 372.3017248170669 384.1026510261707 372.33973158208187 384.00250165942583 372.33973158208187 C383.9023273240032 372.33973158208187 383.80215298858053 372.3017248170669 383.72579877180027 372.2256988584021 L381.26406191927623 369.7683216275319 L378.80232506675236 372.2190868247239 C378.7260207873276 372.2950382115802 378.62582148322724 372.33292069024793 378.5256970851601 372.33292069024793 C378.4253729376707 372.33292069024793 378.3250987275366 372.2949014965982 378.24894426017903 372.2190868247239 C378.0962108579406 372.0670349073945 378.0962108579406 371.8202270788569 378.24894426017903 371.66817516152736 L380.711230423615 369.2168631044071 L378.2483699805889 366.75948587353685 C378.0962108579406 366.60688709627914 378.0962108579406 366.3600668391068 378.249493571091 366.2085742103403 C378.32552319505953 366.13288382481346 378.42542287502613 366.09501377478045 378.5254224297042 366.09501377478045 Z M381.2675075968157 360.2543508826647 C376.3179915607992 360.2543508826647 372.2454004585762 364.32213117322226 372.26757264448224 369.2542608663201 C372.24547536460955 374.1694379016416 376.2900266416383 378.2321100233236 381.2272331194885 378.25408384953244 C381.2406662681568 378.25414599270607 381.2540744481474 378.25417084997554 381.2674826281379 378.25417084997554 C386.21697369547655 378.25417084997554 390.2895398290218 374.1863781307833 390.26739261179347 369.2542608663201 C390.2894649229883 364.3390838309988 386.2449386146375 360.2764241379514 381.30773213678725 360.25443788310787 C381.29432395679663 360.2543757399342 381.2809157768063 360.2543508826647 381.2675075968157 360.2543508826647 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Subtraction_6-7fdbe" fill="#8E8E93" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Group_28" class="group firer ie-background commentable non-processed" customid="Symbol only button" datasizewidth="157.00px" datasizeheight="44.00px" >\
        <div id="s-Button_4" class="button multiline manualfit firer click commentable non-processed" customid="Button"   datasizewidth="50.00px" datasizeheight="50.00px" dataX="17.36" dataY="881.72" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Button_4_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Path_27" class="path firer click commentable non-processed" customid="Play icon"   datasizewidth="12.55px" datasizeheight="14.05px" dataX="38.36" dataY="899.58"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="12.550798416137695" height="14.053009033203125" viewBox="38.36254295532649 899.5811614153838 12.550798416137695 14.053009033203125" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_27-7fdbe" d="M39.35864242737239 913.6341704485869 C39.05424293701594 913.6341704485869 38.81074318115657 913.5231627581572 38.62814315979426 913.302169716165 C38.45104202454036 913.0861662981963 38.36254295532649 912.7981719134307 38.36254295532649 912.4391631243682 L38.36254295532649 900.7681578753447 C38.36254295532649 900.4081725237822 38.45104202454036 900.1201628802276 38.62814315979426 899.9041594622588 C38.81074318115657 899.6891631243682 39.05424293701594 899.5811614153838 39.35864242737239 899.5811614153838 C39.524642793583325 899.5811614153838 39.68234237854426 899.6111601946807 39.83174308960383 899.6721648333526 C39.98124298279231 899.7271727679229 40.13894256775325 899.802169716165 40.304942933964185 899.89616385679 L49.98364242737239 905.4991606829619 C50.33224281494563 905.698165809915 50.572942583012036 905.8781584856963 50.70584091370051 906.0391692278838 C50.84414276306575 906.1941680071807 50.913341371464185 906.3821715472197 50.913341371464185 906.6031645892119 C50.913341371464185 906.8241576312041 50.84414276306575 907.0151671526885 50.70584091370051 907.1761626360869 C50.572942583012036 907.3311614153838 50.33224281494563 907.5111693499541 49.98364242737239 907.7151641009307 L40.304942933964185 913.3101653216338 C40.13894256775325 913.4101714251494 39.98124298279231 913.4871672747588 39.83174308960383 913.5431670306182 C39.68234237854426 913.6031645892119 39.524642793583325 913.6341704485869 39.35864242737239 913.6341704485869 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_27-7fdbe" fill="#FFFFFF" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Button_5" class="button multiline manualfit firer click commentable non-processed" customid="Filled button"   datasizewidth="283.27px" datasizeheight="50.00px" dataX="78.36" dataY="699.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_5_0">Import your Questions</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Group_1" class="group firer ie-background commentable non-processed" customid="Input field" datasizewidth="0.00px" datasizeheight="0.00px" >\
        <div id="s-Input_text_1" class="text firer focusin focusout commentable non-processed" customid="Dialog input"  datasizewidth="355.27px" datasizeheight="40.00px" dataX="42.75" dataY="490.25" ><div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Label"/></div></div>  </div></div></div>\
        <div id="s-Path_1" class="path firer click commentable hidden non-processed" customid="Cancel icon"   datasizewidth="18.00px" datasizeheight="18.00px" dataX="372.27" dataY="501.25"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="18.000000000000227" height="17.999819967310827" viewBox="372.26748252688355 501.2543508826647 18.000000000000227 17.999819967310827" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_1-7fdbe" d="M378.5254224297042 507.09501377478045 C378.6256217338045 507.09501377478045 378.7258959439385 507.13302053979544 378.80232506675236 507.20912107026857 L381.26461123018834 509.66595144121055 L383.7324404401009 507.20912107026857 C383.80879465688116 507.1330951116039 383.9089689923039 507.0950883465889 384.0091433277266 507.0950883465889 C384.1092926944713 507.0950883465889 384.2094420612162 507.1330951116039 384.28582124667435 507.20912107026857 C384.43800533800066 507.3606261276698 384.43855464891266 507.6079808161357 384.28582124667435 507.7600327334651 L381.8174427258497 510.2174099643354 L384.2797538579635 512.6753340551338 C384.431912980612 512.8268391125351 384.4324872602019 513.0741938010009 384.2791795783736 513.2256988584021 C384.20280039291555 513.3017248170669 384.1026510261707 513.3397315820819 384.00250165942583 513.3397315820819 C383.9023273240032 513.3397315820819 383.80215298858053 513.3017248170669 383.72579877180027 513.2256988584021 L381.26406191927623 510.7683216275319 L378.80232506675236 513.219086824724 C378.7260207873276 513.2950382115803 378.62582148322724 513.3329206902479 378.5256970851601 513.3329206902479 C378.4253729376707 513.3329206902479 378.3250987275366 513.2949014965982 378.24894426017903 513.219086824724 C378.0962108579406 513.0670349073945 378.0962108579406 512.8202270788569 378.24894426017903 512.6681751615274 L380.711230423615 510.2168631044071 L378.2483699805889 507.75948587353685 C378.0962108579406 507.60688709627914 378.0962108579406 507.3600668391068 378.249493571091 507.2085742103403 C378.32552319505953 507.13288382481346 378.42542287502613 507.09501377478045 378.5254224297042 507.09501377478045 Z M381.2675075968157 501.2543508826647 C376.3179915607992 501.2543508826647 372.2454004585762 505.32213117322226 372.26757264448224 510.2542608663201 C372.24547536460955 515.1694379016416 376.2900266416383 519.2321100233237 381.2272331194885 519.2540838495324 C381.2406662681568 519.2541459927061 381.2540744481474 519.2541708499755 381.2674826281379 519.2541708499755 C386.21697369547655 519.2541708499755 390.2895398290218 515.1863781307833 390.26739261179347 510.2542608663201 C390.2894649229883 505.3390838309988 386.2449386146375 501.2764241379514 381.30773213678725 501.25443788310787 C381.29432395679663 501.2543757399342 381.2809157768063 501.2543508826647 381.2675075968157 501.2543508826647 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_1-7fdbe" fill="#8E8E93" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Button_6" class="button multiline manualfit firer click commentable non-processed" customid="Filled button"   datasizewidth="355.27px" datasizeheight="50.00px" dataX="42.36" dataY="783.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_6_0">Save</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_7" class="button multiline manualfit firer click commentable non-processed" customid="Filled button"   datasizewidth="355.27px" datasizeheight="50.00px" dataX="42.07" dataY="554.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_7_0">Grade</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Group_2" class="group firer ie-background commentable non-processed" customid="Input field" datasizewidth="0.00px" datasizeheight="0.00px" >\
        <div id="s-Input_text_2" class="text firer focusin focusout commentable non-processed" customid="Dialog input"  datasizewidth="355.27px" datasizeheight="40.00px" dataX="42.75" dataY="634.25" ><div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Label"/></div></div>  </div></div></div>\
        <div id="s-Path_2" class="path firer click commentable hidden non-processed" customid="Cancel icon"   datasizewidth="18.00px" datasizeheight="18.00px" dataX="372.27" dataY="645.25"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="18.000000000000227" height="17.999819967310827" viewBox="372.26748252688355 645.2543508826648 18.000000000000227 17.999819967310827" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_2-7fdbe" d="M378.5254224297042 651.0950137747806 C378.6256217338045 651.0950137747806 378.7258959439385 651.1330205397956 378.80232506675236 651.2091210702687 L381.26461123018834 653.6659514412106 L383.7324404401009 651.2091210702687 C383.80879465688116 651.133095111604 383.9089689923039 651.0950883465889 384.0091433277266 651.0950883465889 C384.1092926944713 651.0950883465889 384.2094420612162 651.133095111604 384.28582124667435 651.2091210702687 C384.43800533800066 651.3606261276699 384.43855464891266 651.6079808161358 384.28582124667435 651.7600327334652 L381.8174427258497 654.2174099643354 L384.2797538579635 656.6753340551339 C384.431912980612 656.8268391125351 384.4324872602019 657.074193801001 384.2791795783736 657.2256988584022 C384.20280039291555 657.301724817067 384.1026510261707 657.3397315820819 384.00250165942583 657.3397315820819 C383.9023273240032 657.3397315820819 383.80215298858053 657.301724817067 383.72579877180027 657.2256988584022 L381.26406191927623 654.7683216275319 L378.80232506675236 657.219086824724 C378.7260207873276 657.2950382115803 378.62582148322724 657.332920690248 378.5256970851601 657.332920690248 C378.4253729376707 657.332920690248 378.3250987275366 657.2949014965983 378.24894426017903 657.219086824724 C378.0962108579406 657.0670349073945 378.0962108579406 656.820227078857 378.24894426017903 656.6681751615274 L380.711230423615 654.2168631044071 L378.2483699805889 651.759485873537 C378.0962108579406 651.6068870962793 378.0962108579406 651.3600668391068 378.249493571091 651.2085742103404 C378.32552319505953 651.1328838248135 378.42542287502613 651.0950137747806 378.5254224297042 651.0950137747806 Z M381.2675075968157 645.2543508826648 C376.3179915607992 645.2543508826648 372.2454004585762 649.3221311732224 372.26757264448224 654.2542608663202 C372.24547536460955 659.1694379016417 376.2900266416383 663.2321100233237 381.2272331194885 663.2540838495324 C381.2406662681568 663.2541459927061 381.2540744481474 663.2541708499756 381.2674826281379 663.2541708499756 C386.21697369547655 663.2541708499756 390.2895398290218 659.1863781307834 390.26739261179347 654.2542608663202 C390.2894649229883 649.3390838309988 386.2449386146375 645.2764241379515 381.30773213678725 645.2544378831079 C381.29432395679663 645.2543757399342 381.2809157768063 645.2543508826648 381.2675075968157 645.2543508826648 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_2-7fdbe" fill="#8E8E93" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
      </div>\
\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;