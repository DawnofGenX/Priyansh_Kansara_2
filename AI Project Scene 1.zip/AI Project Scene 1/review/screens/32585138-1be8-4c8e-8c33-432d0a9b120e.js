var content='<div class="ui-page " deviceName="iphone16promax" deviceType="mobile" deviceWidth="440" deviceHeight="956">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS iphone-device canvas firer commentable non-processed" alignment="left" name="Template 1"width="440" height="956">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/templates/f39803f7-df02-4169-93eb-7547fb8c961a/style-1738230134512.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-32585138-1be8-4c8e-8c33-432d0a9b120e" class="screen growth-vertical devMobile devIOS iphone-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Correct_Screen"width="440" height="956">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/screens/32585138-1be8-4c8e-8c33-432d0a9b120e/style-1738230134512.css" />\
      <link type="text/css" rel="stylesheet" href="./review/screens/32585138-1be8-4c8e-8c33-432d0a9b120e/fonts-1738230134512.css" />\
      <div class="freeLayout">\
      <div id="s-Group_28" class="group firer ie-background commentable non-processed" customid="Symbol only button" datasizewidth="157.00px" datasizeheight="44.00px" >\
        <div id="s-Button_1" class="button multiline manualfit firer click commentable non-processed" customid="Button"   datasizewidth="94.00px" datasizeheight="84.00px" dataX="173.00" dataY="239.26" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Button_1_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Path_27" class="path firer click commentable non-processed" customid="Play icon"   datasizewidth="12.55px" datasizeheight="14.05px" dataX="212.48" dataY="269.27"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="12.550798416137695" height="14.053009033203125" viewBox="212.4800000000007 269.2722640325384 12.550798416137695 14.053009033203125" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_27-32585" d="M213.4760994720466 283.3252730657415 C213.17169998169015 283.3252730657415 212.92820022583078 283.2142653753118 212.74560020446847 282.9932723333196 C212.56849906921457 282.7772689153509 212.4800000000007 282.48927453058525 212.4800000000007 282.13026574152275 L212.4800000000007 270.4592604924993 C212.4800000000007 270.0992751409368 212.56849906921457 269.8112654973821 212.74560020446847 269.5952620794134 C212.92820022583078 269.38026574152275 213.17169998169015 269.2722640325384 213.4760994720466 269.2722640325384 C213.64209983825754 269.2722640325384 213.79979942321847 269.30226281183525 213.94920013427804 269.3632674505071 C214.09870002746652 269.41827538507744 214.25639961242746 269.4932723333196 214.4223999786384 269.5872664739446 L224.1010994720466 275.1902633001165 C224.44969985961984 275.3892684270696 224.69039962768625 275.5692611028509 224.82329795837472 275.7302718450384 C224.96159980773996 275.88527062433525 225.0307984161384 276.0732741643743 225.0307984161384 276.2942672063665 C225.0307984161384 276.5152602483587 224.96159980773996 276.70626976984306 224.82329795837472 276.8672652532415 C224.69039962768625 277.0222640325384 224.44969985961984 277.2022719671087 224.1010994720466 277.40626671808525 L214.4223999786384 283.0012679387884 C214.25639961242746 283.101274042304 214.09870002746652 283.1782698919134 213.94920013427804 283.23426964777275 C213.79979942321847 283.2942672063665 213.64209983825754 283.3252730657415 213.4760994720466 283.3252730657415 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_27-32585" fill="#FFFFFF" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Text_1" class="richtext manualfit firer ie-background commentable non-processed" customid="You are correct!"   datasizewidth="440.00px" datasizeheight="58.00px" dataX="0.00" dataY="341.01" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_1_0">You are correct!</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_2" class="button multiline manualfit firer click commentable non-processed" customid="Filled button"   datasizewidth="355.27px" datasizeheight="57.25px" dataX="42.36" dataY="539.01" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_2_0">View LeaderBoard</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_3" class="button multiline manualfit firer click commentable non-processed" customid="Filled button"   datasizewidth="355.27px" datasizeheight="57.25px" dataX="42.36" dataY="618.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_3_0">Use Powerup</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Group_29" class="group firer ie-background commentable non-processed" customid="Symbol only button" datasizewidth="157.00px" datasizeheight="44.00px" >\
        <div id="s-Button_4" class="button multiline manualfit firer click commentable non-processed" customid="Button"   datasizewidth="50.00px" datasizeheight="50.00px" dataX="361.00" dataY="862.00" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Button_4_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Path_28" class="path firer click commentable non-processed" customid="Play icon"   datasizewidth="12.55px" datasizeheight="14.05px" dataX="382.00" dataY="879.86"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="12.550798416137695" height="14.053009033203125" viewBox="382.0 879.8645362056903 12.550798416137695 14.053009033203125" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_28-32585" d="M382.9960994720459 893.9175452388935 C382.69169998168945 893.9175452388935 382.4482002258301 893.8065375484638 382.2656002044678 893.5855445064716 C382.08849906921387 893.3695410885028 382.0 893.0815467037372 382.0 892.7225379146747 L382.0 881.0515326656513 C382.0 880.6915473140888 382.08849906921387 880.4035376705341 382.2656002044678 880.1875342525653 C382.4482002258301 879.9725379146747 382.69169998168945 879.8645362056903 382.9960994720459 879.8645362056903 C383.16209983825684 879.8645362056903 383.3197994232178 879.8945349849872 383.46920013427734 879.9555396236591 C383.6187000274658 880.0105475582294 383.77639961242676 880.0855445064716 383.9423999786377 880.1795386470966 L393.6210994720459 885.7825354732685 C393.96969985961914 885.9815406002216 394.21039962768555 886.1615332760028 394.343297958374 886.3225440181903 C394.48159980773926 886.4775427974872 394.5507984161377 886.6655463375263 394.5507984161377 886.8865393795185 C394.5507984161377 887.1075324215107 394.48159980773926 887.298541942995 394.343297958374 887.4595374263935 C394.21039962768555 887.6145362056903 393.96969985961914 887.7945441402607 393.6210994720459 887.9985388912372 L383.9423999786377 893.5935401119403 C383.77639961242676 893.693546215456 383.6187000274658 893.7705420650653 383.46920013427734 893.8265418209247 C383.3197994232178 893.8865393795185 383.16209983825684 893.9175452388935 382.9960994720459 893.9175452388935 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_28-32585" fill="#FFFFFF" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Button_5" class="button multiline manualfit firer click commentable non-processed" customid="Filled button"   datasizewidth="355.27px" datasizeheight="57.25px" dataX="42.36" dataY="386.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_5_0">You have been awarded 100 points</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_6" class="button multiline manualfit firer click commentable non-processed" customid="Filled button"   datasizewidth="355.27px" datasizeheight="57.25px" dataX="42.36" dataY="460.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_6_0">Streaks: 2</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;