var content='<div class="ui-page " deviceName="iphone16promax" deviceType="mobile" deviceWidth="440" deviceHeight="956">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS iphone-device canvas firer commentable non-processed" alignment="left" name="Template 1"width="440" height="956">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/templates/f39803f7-df02-4169-93eb-7547fb8c961a/style-1738230134512.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-286f34bf-c644-4756-9153-e492441420e9" class="screen growth-vertical devMobile devIOS iphone-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="View Students"width="440" height="956">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/screens/286f34bf-c644-4756-9153-e492441420e9/style-1738230134512.css" />\
      <link type="text/css" rel="stylesheet" href="./review/screens/286f34bf-c644-4756-9153-e492441420e9/fonts-1738230134512.css" />\
      <div class="freeLayout">\
      <div id="s-Button_1" class="button multiline manualfit firer click commentable non-processed" customid="Filled button"   datasizewidth="377.09px" datasizeheight="50.00px" dataX="36.67" dataY="108.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_1_0">Student Name</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Group_28" class="group firer ie-background commentable non-processed" customid="Symbol only button" datasizewidth="157.00px" datasizeheight="44.00px" >\
        <div id="s-Button_4" class="button multiline manualfit firer click commentable non-processed" customid="Button"   datasizewidth="50.57px" datasizeheight="50.00px" dataX="17.36" dataY="881.72" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Button_4_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Path_27" class="path firer click commentable non-processed" customid="Play icon"   datasizewidth="12.55px" datasizeheight="14.05px" dataX="38.60" dataY="899.58"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="12.550798416137468" height="14.053009033203125" viewBox="38.602323631457125 899.5811614153838 12.550798416137468 14.053009033203125" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_27-286f3" d="M39.59842310350301 913.6341704485869 C39.294023613146564 913.6341704485869 39.050523857287196 913.5231627581572 38.86792383592489 913.302169716165 C38.69082270067099 913.0861662981963 38.602323631457125 912.7981719134307 38.602323631457125 912.4391631243682 L38.602323631457125 900.7681578753447 C38.602323631457125 900.4081725237822 38.69082270067099 900.1201628802276 38.86792383592489 899.9041594622588 C39.050523857287196 899.6891631243682 39.294023613146564 899.5811614153838 39.59842310350301 899.5811614153838 C39.76442346971394 899.5811614153838 39.92212305467487 899.6111601946807 40.07152376573444 899.6721648333526 C40.22102365892292 899.7271727679229 40.378723243883854 899.802169716165 40.544723610094785 899.89616385679 L50.22342310350281 905.4991606829619 C50.57202349107605 905.698165809915 50.81272325914245 905.8781584856963 50.94562158983092 906.0391692278838 C51.083923439196155 906.1941680071807 51.15312204759459 906.3821715472197 51.15312204759459 906.6031645892119 C51.15312204759459 906.8241576312041 51.083923439196155 907.0151671526885 50.94562158983092 907.1761626360869 C50.81272325914245 907.3311614153838 50.57202349107605 907.5111693499541 50.22342310350281 907.7151641009307 L40.544723610094785 913.3101653216338 C40.378723243883854 913.4101714251494 40.22102365892292 913.4871672747588 40.07152376573444 913.5431670306182 C39.92212305467487 913.6031645892119 39.76442346971394 913.6341704485869 39.59842310350301 913.6341704485869 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_27-286f3" fill="#FFFFFF" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Button_3" class="button multiline manualfit firer click commentable non-processed" customid="Filled button"   datasizewidth="377.09px" datasizeheight="50.00px" dataX="36.67" dataY="332.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_3_0">Student Name</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_6" class="button multiline manualfit firer click commentable non-processed" customid="Filled button"   datasizewidth="377.09px" datasizeheight="50.00px" dataX="36.67" dataY="256.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_6_0">Student Name</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_8" class="button multiline manualfit firer click commentable non-processed" customid="Filled button"   datasizewidth="377.09px" datasizeheight="50.00px" dataX="36.67" dataY="180.07" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_8_0">Student Name</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_14" class="button multiline manualfit firer click commentable non-processed" customid="Filled button"   datasizewidth="377.09px" datasizeheight="50.00px" dataX="36.67" dataY="822.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_14_0">Student Name</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_16" class="button multiline manualfit firer click commentable non-processed" customid="Filled button"   datasizewidth="377.09px" datasizeheight="50.00px" dataX="36.67" dataY="469.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_16_0">Student Name</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_18" class="button multiline manualfit firer click commentable non-processed" customid="Filled button"   datasizewidth="377.09px" datasizeheight="50.00px" dataX="36.67" dataY="401.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_18_0">Student Name</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_10" class="button multiline manualfit firer click commentable non-processed" customid="Filled button"   datasizewidth="377.09px" datasizeheight="50.00px" dataX="36.67" dataY="755.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_10_0">Student Name</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_12" class="button multiline manualfit firer click commentable non-processed" customid="Filled button"   datasizewidth="377.09px" datasizeheight="50.00px" dataX="36.67" dataY="680.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_12_0">Student Name</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_20" class="button multiline manualfit firer click commentable non-processed" customid="Filled button"   datasizewidth="377.09px" datasizeheight="50.00px" dataX="36.67" dataY="611.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_20_0">Student Name</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_22" class="button multiline manualfit firer click commentable non-processed" customid="Filled button"   datasizewidth="377.09px" datasizeheight="50.00px" dataX="36.67" dataY="539.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_22_0">Student Name</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;