var content='<div class="ui-page " deviceName="iphone16promax" deviceType="mobile" deviceWidth="440" deviceHeight="956">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS iphone-device canvas firer commentable non-processed" alignment="left" name="Template 1"width="440" height="956">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/templates/f39803f7-df02-4169-93eb-7547fb8c961a/style-1738230134512.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-555d8318-848f-4b56-a82c-4b71b013f9f1" class="screen growth-vertical devMobile devIOS iphone-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Multiple_Question"width="440" height="956">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/screens/555d8318-848f-4b56-a82c-4b71b013f9f1/style-1738230134512.css" />\
      <link type="text/css" rel="stylesheet" href="./review/screens/555d8318-848f-4b56-a82c-4b71b013f9f1/fonts-1738230134512.css" />\
      <div class="freeLayout">\
      <div id="s-Button_1" class="button multiline manualfit firer click commentable non-processed" customid="Filled button"   datasizewidth="355.27px" datasizeheight="81.00px" dataX="42.98" dataY="403.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_1_0">Multiple Choice &nbsp;1</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_2" class="button multiline manualfit firer click commentable non-processed" customid="Filled button"   datasizewidth="355.27px" datasizeheight="81.00px" dataX="42.98" dataY="403.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_2_0">Multiple Choice &nbsp;1</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_3" class="button multiline manualfit firer click commentable non-processed" customid="Filled button"   datasizewidth="355.27px" datasizeheight="81.00px" dataX="42.36" dataY="531.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_3_0">Multiple Choice &nbsp;2</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_4" class="button multiline manualfit firer click commentable non-processed" customid="Filled button"   datasizewidth="355.27px" datasizeheight="81.00px" dataX="42.36" dataY="663.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_4_0">Multiple Choice &nbsp;3</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_5" class="button multiline manualfit firer click commentable non-processed" customid="Filled button"   datasizewidth="355.27px" datasizeheight="81.00px" dataX="42.36" dataY="783.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_5_0">Multiple Choice &nbsp;4</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_6" class="button multiline manualfit firer click commentable non-processed" customid="Filled button"   datasizewidth="355.27px" datasizeheight="232.00px" dataX="42.36" dataY="120.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_6_0">Question</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Group_28" class="group firer ie-background commentable non-processed" customid="Symbol only button" datasizewidth="157.00px" datasizeheight="44.00px" >\
        <div id="s-Button_7" class="button multiline manualfit firer click commentable non-processed" customid="Button"   datasizewidth="50.00px" datasizeheight="50.00px" dataX="17.36" dataY="879.73" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Button_7_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Path_27" class="path firer click commentable non-processed" customid="Play icon"   datasizewidth="12.55px" datasizeheight="14.05px" dataX="38.36" dataY="897.60"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="12.550798416137695" height="14.053009033203125" viewBox="38.36254295532672 897.5980431501354 12.550798416137695 14.053009033203125" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_27-555d8" d="M39.358642427372615 911.6510521833385 C39.05424293701617 911.6510521833385 38.810743181156795 911.5400444929088 38.62814315979449 911.3190514509166 C38.451042024540584 911.1030480329479 38.36254295532672 910.8150536481822 38.36254295532672 910.4560448591197 L38.36254295532672 898.7850396100963 C38.36254295532672 898.4250542585338 38.451042024540584 898.1370446149791 38.62814315979449 897.9210411970104 C38.810743181156795 897.7060448591197 39.05424293701617 897.5980431501354 39.358642427372615 897.5980431501354 C39.52464279358355 897.5980431501354 39.68234237854449 897.6280419294322 39.83174308960406 897.6890465681041 C39.98124298279254 897.7440545026744 40.138942567753475 897.8190514509166 40.30494293396441 897.9130455915416 L49.983642427372615 903.5160424177135 C50.33224281494586 903.7150475446666 50.572942583012264 903.8950402204479 50.70584091370074 904.0560509626354 C50.844142763065975 904.2110497419322 50.91334137146441 904.3990532819713 50.91334137146441 904.6200463239635 C50.91334137146441 904.8410393659557 50.844142763065975 905.03204888744 50.70584091370074 905.1930443708385 C50.572942583012264 905.3480431501354 50.33224281494586 905.5280510847057 49.983642427372615 905.7320458356822 L40.30494293396441 911.3270470563854 C40.138942567753475 911.427053159901 39.98124298279254 911.5040490095104 39.83174308960406 911.5600487653697 C39.68234237854449 911.6200463239635 39.52464279358355 911.6510521833385 39.358642427372615 911.6510521833385 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_27-555d8" fill="#FFFFFF" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Path_28" class="path firer click commentable non-processed" customid="Play icon"   datasizewidth="12.55px" datasizeheight="14.05px" dataX="393.64" dataY="61.44"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="12.550798416137695" height="14.053009033203125" viewBox="393.6374570446735 61.44179315013548 12.550798416137695 14.053009033203125" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_28-555d8" d="M394.6335565167194 75.4948021833386 C394.32915702636296 75.4948021833386 394.0856572705036 75.38379449290892 393.9030572491413 75.16280145091673 C393.7259561138874 74.94679803294798 393.6374570446735 74.65880364818236 393.6374570446735 74.29979485911986 L393.6374570446735 62.62878961009642 C393.6374570446735 62.26880425853392 393.7259561138874 61.98079461497923 393.9030572491413 61.76479119701048 C394.0856572705036 61.54979485911986 394.32915702636296 61.44179315013548 394.6335565167194 61.44179315013548 C394.79955688293035 61.44179315013548 394.9572564678913 61.47179192943236 395.10665717895085 61.53279656810423 C395.25615707213933 61.587804502674544 395.41385665710027 61.66280145091673 395.5798570233112 61.75679559154173 L405.2585565167194 67.3597924177136 C405.60715690429265 67.55879754466673 405.84785667235906 67.73879022044798 405.98075500304753 67.89980096263548 C406.11905685241277 68.05479974193236 406.1882554608112 68.24280328197142 406.1882554608112 68.4637963239636 C406.1882554608112 68.6847893659558 406.11905685241277 68.87579888744017 405.98075500304753 69.0367943708386 C405.84785667235906 69.19179315013548 405.60715690429265 69.3718010847058 405.2585565167194 69.57579583568236 L395.5798570233112 75.17079705638548 C395.41385665710027 75.2708031599011 395.25615707213933 75.34779900951048 395.10665717895085 75.40379876536986 C394.9572564678913 75.4637963239636 394.79955688293035 75.4948021833386 394.6335565167194 75.4948021833386 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_28-555d8" fill="#FFFFFF" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_4" class="path firer commentable non-processed" customid="Settings"   datasizewidth="59.68px" datasizeheight="54.03px" dataX="363.80" dataY="875.71"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="59.681271477663586" height="54.02723479270912" viewBox="363.7968213058418 875.7062857151034 59.681271477663586 54.02723479270912" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_4-555d8" d="M404.39269370321813 891.5533473495924 C407.5112820609739 891.5533473495924 410.1962370944409 889.4731199354453 411.3223866911627 886.5973530892575 L420.8217228988774 886.5973530892575 C422.2655423500143 886.5973530892575 423.47809278350536 885.2512933195266 423.47809278350536 883.6298339599704 C423.47809278350536 882.0084094556593 422.2655423500143 880.6929110967226 420.8217228988774 880.6929110967226 L411.3223866911627 880.6929110967226 C410.2251480713684 877.7865844995141 407.53986720981294 875.7062857151034 404.39269370321813 875.7062857151034 C401.24552019662326 875.7062857151034 398.56023620210544 877.7865844995141 397.46332654336203 880.6929110967226 L366.5397894038695 880.6929110967226 C365.009501757272 880.6929110967226 363.7968213058418 882.0084094556593 363.7968213058418 883.6298339599704 C363.7968213058418 885.2512933195266 365.009501757272 886.5973530892575 366.5397894038695 886.5973530892575 L397.46332654336203 886.5973530892575 C398.589147179033 889.4731199354453 401.274424907626 891.5533473495924 404.39269370321813 891.5533473495924 Z M404.39269370321813 887.3927862957895 C402.40057450434784 887.3927862957895 400.84144323951415 885.7101675996262 400.84144323951415 883.6298339599704 C400.84144323951415 881.488342643481 402.40057450434784 879.8363218731306 404.39269370321813 879.8363218731306 C406.4140434411796 879.8363218731306 407.9442637290858 881.488342643481 407.9442637290858 883.6298339599704 C407.9442637290858 885.7101675996262 406.4140434411796 887.3927862957895 404.39269370321813 887.3927862957895 Z M366.4531598608458 899.7829960160591 C365.009501757272 899.7829960160591 363.7968213058418 901.0983898092607 363.7968213058418 902.7197462628553 C363.7968213058418 904.3108184878423 365.009501757272 905.6568417425547 366.4531598608458 905.6568417425547 L376.27010483020905 905.6568417425547 C377.39618863472066 908.5935919893509 380.08140370406596 910.6434322689289 383.22844562624044 910.6434322689289 C386.3470371169586 910.6434322689289 389.0323179785141 908.5935919893509 390.15813861418496 905.6568417425547 L420.73499623401966 905.6568417425547 C422.2655423500143 905.6568417425547 423.47809278350536 904.3414479493531 423.47809278350536 902.7197462628553 C423.47809278350536 901.0983898092607 422.2655423500143 899.7829960160591 420.73499623401966 899.7829960160591 L390.15813861418496 899.7829960160591 C389.0323179785141 896.8765299978705 386.3470371169586 894.8270382707428 383.22844562624044 894.8270382707428 C380.08140370406596 894.8270382707428 377.39618863472066 896.8765299978705 376.27010483020905 899.7829960160591 L366.4531598608458 899.7829960160591 Z M383.22844562624044 906.5134674811653 C381.2363326932949 906.5134674811653 379.64829045153374 904.830848785002 379.64829045153374 902.7197462628553 C379.64829045153374 900.5783595121011 381.2363326932949 898.9570030585063 383.22844562624044 898.9570030585063 C385.2208906531992 898.9570030585063 386.78002191803284 900.5783595121011 386.78002191803284 902.7197462628553 C386.78002191803284 904.830848785002 385.2208906531992 906.5134674811653 383.22844562624044 906.5134674811653 Z M404.39269370321813 929.7335205078125 C407.53986720981294 929.7335205078125 410.2251480713684 927.6530474471766 411.3223866911627 924.7469299814383 L420.8217228988774 924.7469299814383 C422.2655423500143 924.7469299814383 423.47809278350536 923.4311876357865 423.47809278350536 921.8098345017389 C423.47809278350536 920.1578419475392 422.2655423500143 918.8730842549427 420.8217228988774 918.8730842549427 L411.3223866911627 918.8730842549427 C410.2251480713684 915.9666149172069 407.53986720981294 913.886141856571 404.39269370321813 913.886141856571 C401.274424907626 913.886141856571 398.56023620210544 915.9666149172069 397.46332654336203 918.8730842549427 L366.5397894038695 918.8730842549427 C365.009501757272 918.8730842549427 363.7968213058418 920.1884747285972 363.7968213058418 921.8098345017389 C363.7968213058418 923.4005548547285 365.009501757272 924.7469299814383 366.5397894038695 924.7469299814383 L397.46332654336203 924.7469299814383 C398.56023620210544 927.6530474471766 401.24552019662326 929.7335205078125 404.39269370321813 929.7335205078125 Z M404.39269370321813 925.5729196194438 C402.40057450434784 925.5729196194438 400.84144323951415 923.8903009232805 400.84144323951415 921.8098345017389 C400.84144323951415 919.6684477509847 402.40057450434784 918.0467427449397 404.39269370321813 918.0467427449397 C406.4140434411796 918.0467427449397 407.9442637290858 919.6684477509847 407.9442637290858 921.8098345017389 C407.9442637290858 923.8903009232805 406.4140434411796 925.5729196194438 404.39269370321813 925.5729196194438 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_4-555d8" fill="#8E8E93" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;