	window.widgets = {
		descriptionMap : widgetDescriptionMap = {},
		rootWidgetMap : widgetRootMap = {}
	};

	widgets.descriptionMap[["s-Button_1", "32585138-1be8-4c8e-8c33-432d0a9b120e"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "32585138-1be8-4c8e-8c33-432d0a9b120e"]] = ["Symbol only", "s-Group_28"]; 

	widgets.descriptionMap[["s-Path_27", "32585138-1be8-4c8e-8c33-432d0a9b120e"]] = ""; 

			widgets.rootWidgetMap[["s-Path_27", "32585138-1be8-4c8e-8c33-432d0a9b120e"]] = ["Symbol only", "s-Group_28"]; 

	widgets.descriptionMap[["s-Button_2", "32585138-1be8-4c8e-8c33-432d0a9b120e"]] = ""; 

			widgets.rootWidgetMap[["s-Button_2", "32585138-1be8-4c8e-8c33-432d0a9b120e"]] = ["Button", "s-Button_2"]; 

	widgets.descriptionMap[["s-Button_3", "32585138-1be8-4c8e-8c33-432d0a9b120e"]] = ""; 

			widgets.rootWidgetMap[["s-Button_3", "32585138-1be8-4c8e-8c33-432d0a9b120e"]] = ["Button", "s-Button_3"]; 

	widgets.descriptionMap[["s-Button_4", "32585138-1be8-4c8e-8c33-432d0a9b120e"]] = ""; 

			widgets.rootWidgetMap[["s-Button_4", "32585138-1be8-4c8e-8c33-432d0a9b120e"]] = ["Symbol only", "s-Group_29"]; 

	widgets.descriptionMap[["s-Path_28", "32585138-1be8-4c8e-8c33-432d0a9b120e"]] = ""; 

			widgets.rootWidgetMap[["s-Path_28", "32585138-1be8-4c8e-8c33-432d0a9b120e"]] = ["Symbol only", "s-Group_29"]; 

	widgets.descriptionMap[["s-Button_5", "32585138-1be8-4c8e-8c33-432d0a9b120e"]] = ""; 

			widgets.rootWidgetMap[["s-Button_5", "32585138-1be8-4c8e-8c33-432d0a9b120e"]] = ["Button", "s-Button_5"]; 

	widgets.descriptionMap[["s-Button_6", "32585138-1be8-4c8e-8c33-432d0a9b120e"]] = ""; 

			widgets.rootWidgetMap[["s-Button_6", "32585138-1be8-4c8e-8c33-432d0a9b120e"]] = ["Button", "s-Button_6"]; 

	widgets.descriptionMap[["s-Button_1", "af64949c-5f16-439c-9f2b-bf2896b9945f"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "af64949c-5f16-439c-9f2b-bf2896b9945f"]] = ["Button", "s-Button_1"]; 

	widgets.descriptionMap[["s-Button_4", "af64949c-5f16-439c-9f2b-bf2896b9945f"]] = ""; 

			widgets.rootWidgetMap[["s-Button_4", "af64949c-5f16-439c-9f2b-bf2896b9945f"]] = ["Symbol only", "s-Group_28"]; 

	widgets.descriptionMap[["s-Path_27", "af64949c-5f16-439c-9f2b-bf2896b9945f"]] = ""; 

			widgets.rootWidgetMap[["s-Path_27", "af64949c-5f16-439c-9f2b-bf2896b9945f"]] = ["Symbol only", "s-Group_28"]; 

	widgets.descriptionMap[["s-Button_2", "af64949c-5f16-439c-9f2b-bf2896b9945f"]] = ""; 

			widgets.rootWidgetMap[["s-Button_2", "af64949c-5f16-439c-9f2b-bf2896b9945f"]] = ["Button", "s-Button_2"]; 

	widgets.descriptionMap[["s-Button_3", "af64949c-5f16-439c-9f2b-bf2896b9945f"]] = ""; 

			widgets.rootWidgetMap[["s-Button_3", "af64949c-5f16-439c-9f2b-bf2896b9945f"]] = ["Button", "s-Button_3"]; 

	widgets.descriptionMap[["s-Button_5", "af64949c-5f16-439c-9f2b-bf2896b9945f"]] = ""; 

			widgets.rootWidgetMap[["s-Button_5", "af64949c-5f16-439c-9f2b-bf2896b9945f"]] = ["Button", "s-Button_5"]; 

	widgets.descriptionMap[["s-Button_6", "af64949c-5f16-439c-9f2b-bf2896b9945f"]] = ""; 

			widgets.rootWidgetMap[["s-Button_6", "af64949c-5f16-439c-9f2b-bf2896b9945f"]] = ["Button", "s-Button_6"]; 

	widgets.descriptionMap[["s-Button_7", "af64949c-5f16-439c-9f2b-bf2896b9945f"]] = ""; 

			widgets.rootWidgetMap[["s-Button_7", "af64949c-5f16-439c-9f2b-bf2896b9945f"]] = ["Button", "s-Button_7"]; 

	widgets.descriptionMap[["s-Button_8", "af64949c-5f16-439c-9f2b-bf2896b9945f"]] = ""; 

			widgets.rootWidgetMap[["s-Button_8", "af64949c-5f16-439c-9f2b-bf2896b9945f"]] = ["Button", "s-Button_8"]; 

	widgets.descriptionMap[["s-Button_9", "af64949c-5f16-439c-9f2b-bf2896b9945f"]] = ""; 

			widgets.rootWidgetMap[["s-Button_9", "af64949c-5f16-439c-9f2b-bf2896b9945f"]] = ["Button", "s-Button_9"]; 

	widgets.descriptionMap[["s-Button_14", "af64949c-5f16-439c-9f2b-bf2896b9945f"]] = ""; 

			widgets.rootWidgetMap[["s-Button_14", "af64949c-5f16-439c-9f2b-bf2896b9945f"]] = ["Button", "s-Button_14"]; 

	widgets.descriptionMap[["s-Button_15", "af64949c-5f16-439c-9f2b-bf2896b9945f"]] = ""; 

			widgets.rootWidgetMap[["s-Button_15", "af64949c-5f16-439c-9f2b-bf2896b9945f"]] = ["Button", "s-Button_15"]; 

	widgets.descriptionMap[["s-Button_16", "af64949c-5f16-439c-9f2b-bf2896b9945f"]] = ""; 

			widgets.rootWidgetMap[["s-Button_16", "af64949c-5f16-439c-9f2b-bf2896b9945f"]] = ["Button", "s-Button_16"]; 

	widgets.descriptionMap[["s-Button_17", "af64949c-5f16-439c-9f2b-bf2896b9945f"]] = ""; 

			widgets.rootWidgetMap[["s-Button_17", "af64949c-5f16-439c-9f2b-bf2896b9945f"]] = ["Button", "s-Button_17"]; 

	widgets.descriptionMap[["s-Button_18", "af64949c-5f16-439c-9f2b-bf2896b9945f"]] = ""; 

			widgets.rootWidgetMap[["s-Button_18", "af64949c-5f16-439c-9f2b-bf2896b9945f"]] = ["Button", "s-Button_18"]; 

	widgets.descriptionMap[["s-Button_19", "af64949c-5f16-439c-9f2b-bf2896b9945f"]] = ""; 

			widgets.rootWidgetMap[["s-Button_19", "af64949c-5f16-439c-9f2b-bf2896b9945f"]] = ["Button", "s-Button_19"]; 

	widgets.descriptionMap[["s-Button_10", "af64949c-5f16-439c-9f2b-bf2896b9945f"]] = ""; 

			widgets.rootWidgetMap[["s-Button_10", "af64949c-5f16-439c-9f2b-bf2896b9945f"]] = ["Button", "s-Button_10"]; 

	widgets.descriptionMap[["s-Button_11", "af64949c-5f16-439c-9f2b-bf2896b9945f"]] = ""; 

			widgets.rootWidgetMap[["s-Button_11", "af64949c-5f16-439c-9f2b-bf2896b9945f"]] = ["Button", "s-Button_11"]; 

	widgets.descriptionMap[["s-Button_12", "af64949c-5f16-439c-9f2b-bf2896b9945f"]] = ""; 

			widgets.rootWidgetMap[["s-Button_12", "af64949c-5f16-439c-9f2b-bf2896b9945f"]] = ["Button", "s-Button_12"]; 

	widgets.descriptionMap[["s-Button_13", "af64949c-5f16-439c-9f2b-bf2896b9945f"]] = ""; 

			widgets.rootWidgetMap[["s-Button_13", "af64949c-5f16-439c-9f2b-bf2896b9945f"]] = ["Button", "s-Button_13"]; 

	widgets.descriptionMap[["s-Button_20", "af64949c-5f16-439c-9f2b-bf2896b9945f"]] = ""; 

			widgets.rootWidgetMap[["s-Button_20", "af64949c-5f16-439c-9f2b-bf2896b9945f"]] = ["Button", "s-Button_20"]; 

	widgets.descriptionMap[["s-Button_21", "af64949c-5f16-439c-9f2b-bf2896b9945f"]] = ""; 

			widgets.rootWidgetMap[["s-Button_21", "af64949c-5f16-439c-9f2b-bf2896b9945f"]] = ["Button", "s-Button_21"]; 

	widgets.descriptionMap[["s-Button_22", "af64949c-5f16-439c-9f2b-bf2896b9945f"]] = ""; 

			widgets.rootWidgetMap[["s-Button_22", "af64949c-5f16-439c-9f2b-bf2896b9945f"]] = ["Button", "s-Button_22"]; 

	widgets.descriptionMap[["s-Button_23", "af64949c-5f16-439c-9f2b-bf2896b9945f"]] = ""; 

			widgets.rootWidgetMap[["s-Button_23", "af64949c-5f16-439c-9f2b-bf2896b9945f"]] = ["Button", "s-Button_23"]; 

	widgets.descriptionMap[["s-Button_1", "7fdbe31e-d2d2-4521-a3e1-dfaf18e423be"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "7fdbe31e-d2d2-4521-a3e1-dfaf18e423be"]] = ["Button", "s-Button_1"]; 

	widgets.descriptionMap[["s-Button_2", "7fdbe31e-d2d2-4521-a3e1-dfaf18e423be"]] = ""; 

			widgets.rootWidgetMap[["s-Button_2", "7fdbe31e-d2d2-4521-a3e1-dfaf18e423be"]] = ["Button", "s-Button_2"]; 

	widgets.descriptionMap[["s-Button_3", "7fdbe31e-d2d2-4521-a3e1-dfaf18e423be"]] = ""; 

			widgets.rootWidgetMap[["s-Button_3", "7fdbe31e-d2d2-4521-a3e1-dfaf18e423be"]] = ["Button", "s-Button_3"]; 

	widgets.descriptionMap[["s-Input_17", "7fdbe31e-d2d2-4521-a3e1-dfaf18e423be"]] = ""; 

			widgets.rootWidgetMap[["s-Input_17", "7fdbe31e-d2d2-4521-a3e1-dfaf18e423be"]] = ["Input", "s-Group_19"]; 

	widgets.descriptionMap[["s-Subtraction_5", "7fdbe31e-d2d2-4521-a3e1-dfaf18e423be"]] = ""; 

			widgets.rootWidgetMap[["s-Subtraction_5", "7fdbe31e-d2d2-4521-a3e1-dfaf18e423be"]] = ["Input", "s-Group_19"]; 

	widgets.descriptionMap[["s-Input_18", "7fdbe31e-d2d2-4521-a3e1-dfaf18e423be"]] = ""; 

			widgets.rootWidgetMap[["s-Input_18", "7fdbe31e-d2d2-4521-a3e1-dfaf18e423be"]] = ["Input", "s-Group_20"]; 

	widgets.descriptionMap[["s-Subtraction_6", "7fdbe31e-d2d2-4521-a3e1-dfaf18e423be"]] = ""; 

			widgets.rootWidgetMap[["s-Subtraction_6", "7fdbe31e-d2d2-4521-a3e1-dfaf18e423be"]] = ["Input", "s-Group_20"]; 

	widgets.descriptionMap[["s-Button_4", "7fdbe31e-d2d2-4521-a3e1-dfaf18e423be"]] = ""; 

			widgets.rootWidgetMap[["s-Button_4", "7fdbe31e-d2d2-4521-a3e1-dfaf18e423be"]] = ["Symbol only", "s-Group_28"]; 

	widgets.descriptionMap[["s-Path_27", "7fdbe31e-d2d2-4521-a3e1-dfaf18e423be"]] = ""; 

			widgets.rootWidgetMap[["s-Path_27", "7fdbe31e-d2d2-4521-a3e1-dfaf18e423be"]] = ["Symbol only", "s-Group_28"]; 

	widgets.descriptionMap[["s-Button_5", "7fdbe31e-d2d2-4521-a3e1-dfaf18e423be"]] = ""; 

			widgets.rootWidgetMap[["s-Button_5", "7fdbe31e-d2d2-4521-a3e1-dfaf18e423be"]] = ["Button", "s-Button_5"]; 

	widgets.descriptionMap[["s-Input_text_1", "7fdbe31e-d2d2-4521-a3e1-dfaf18e423be"]] = ""; 

			widgets.rootWidgetMap[["s-Input_text_1", "7fdbe31e-d2d2-4521-a3e1-dfaf18e423be"]] = ["Input", "s-Group_1"]; 

	widgets.descriptionMap[["s-Path_1", "7fdbe31e-d2d2-4521-a3e1-dfaf18e423be"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "7fdbe31e-d2d2-4521-a3e1-dfaf18e423be"]] = ["Input", "s-Group_1"]; 

	widgets.descriptionMap[["s-Button_6", "7fdbe31e-d2d2-4521-a3e1-dfaf18e423be"]] = ""; 

			widgets.rootWidgetMap[["s-Button_6", "7fdbe31e-d2d2-4521-a3e1-dfaf18e423be"]] = ["Button", "s-Button_6"]; 

	widgets.descriptionMap[["s-Button_7", "7fdbe31e-d2d2-4521-a3e1-dfaf18e423be"]] = ""; 

			widgets.rootWidgetMap[["s-Button_7", "7fdbe31e-d2d2-4521-a3e1-dfaf18e423be"]] = ["Button", "s-Button_7"]; 

	widgets.descriptionMap[["s-Input_text_2", "7fdbe31e-d2d2-4521-a3e1-dfaf18e423be"]] = ""; 

			widgets.rootWidgetMap[["s-Input_text_2", "7fdbe31e-d2d2-4521-a3e1-dfaf18e423be"]] = ["Input", "s-Group_2"]; 

	widgets.descriptionMap[["s-Path_2", "7fdbe31e-d2d2-4521-a3e1-dfaf18e423be"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "7fdbe31e-d2d2-4521-a3e1-dfaf18e423be"]] = ["Input", "s-Group_2"]; 

	widgets.descriptionMap[["s-Button_1", "19feb07a-6501-4dbb-ae9d-bdf42021f3f6"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "19feb07a-6501-4dbb-ae9d-bdf42021f3f6"]] = ["Button", "s-Button_1"]; 

	widgets.descriptionMap[["s-Button_2", "19feb07a-6501-4dbb-ae9d-bdf42021f3f6"]] = ""; 

			widgets.rootWidgetMap[["s-Button_2", "19feb07a-6501-4dbb-ae9d-bdf42021f3f6"]] = ["Button", "s-Button_2"]; 

	widgets.descriptionMap[["s-Button_3", "19feb07a-6501-4dbb-ae9d-bdf42021f3f6"]] = ""; 

			widgets.rootWidgetMap[["s-Button_3", "19feb07a-6501-4dbb-ae9d-bdf42021f3f6"]] = ["Button", "s-Button_3"]; 

	widgets.descriptionMap[["s-Button_4", "19feb07a-6501-4dbb-ae9d-bdf42021f3f6"]] = ""; 

			widgets.rootWidgetMap[["s-Button_4", "19feb07a-6501-4dbb-ae9d-bdf42021f3f6"]] = ["Symbol only", "s-Group_28"]; 

	widgets.descriptionMap[["s-Path_27", "19feb07a-6501-4dbb-ae9d-bdf42021f3f6"]] = ""; 

			widgets.rootWidgetMap[["s-Path_27", "19feb07a-6501-4dbb-ae9d-bdf42021f3f6"]] = ["Symbol only", "s-Group_28"]; 

	widgets.descriptionMap[["s-Button_5", "19feb07a-6501-4dbb-ae9d-bdf42021f3f6"]] = ""; 

			widgets.rootWidgetMap[["s-Button_5", "19feb07a-6501-4dbb-ae9d-bdf42021f3f6"]] = ["Button", "s-Button_5"]; 

	widgets.descriptionMap[["s-Button_6", "19feb07a-6501-4dbb-ae9d-bdf42021f3f6"]] = ""; 

			widgets.rootWidgetMap[["s-Button_6", "19feb07a-6501-4dbb-ae9d-bdf42021f3f6"]] = ["Button", "s-Button_6"]; 

	widgets.descriptionMap[["s-Button_1", "555d8318-848f-4b56-a82c-4b71b013f9f1"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "555d8318-848f-4b56-a82c-4b71b013f9f1"]] = ["Button", "s-Button_1"]; 

	widgets.descriptionMap[["s-Button_2", "555d8318-848f-4b56-a82c-4b71b013f9f1"]] = ""; 

			widgets.rootWidgetMap[["s-Button_2", "555d8318-848f-4b56-a82c-4b71b013f9f1"]] = ["Button", "s-Button_2"]; 

	widgets.descriptionMap[["s-Button_3", "555d8318-848f-4b56-a82c-4b71b013f9f1"]] = ""; 

			widgets.rootWidgetMap[["s-Button_3", "555d8318-848f-4b56-a82c-4b71b013f9f1"]] = ["Button", "s-Button_3"]; 

	widgets.descriptionMap[["s-Button_4", "555d8318-848f-4b56-a82c-4b71b013f9f1"]] = ""; 

			widgets.rootWidgetMap[["s-Button_4", "555d8318-848f-4b56-a82c-4b71b013f9f1"]] = ["Button", "s-Button_4"]; 

	widgets.descriptionMap[["s-Button_5", "555d8318-848f-4b56-a82c-4b71b013f9f1"]] = ""; 

			widgets.rootWidgetMap[["s-Button_5", "555d8318-848f-4b56-a82c-4b71b013f9f1"]] = ["Button", "s-Button_5"]; 

	widgets.descriptionMap[["s-Button_6", "555d8318-848f-4b56-a82c-4b71b013f9f1"]] = ""; 

			widgets.rootWidgetMap[["s-Button_6", "555d8318-848f-4b56-a82c-4b71b013f9f1"]] = ["Button", "s-Button_6"]; 

	widgets.descriptionMap[["s-Button_7", "555d8318-848f-4b56-a82c-4b71b013f9f1"]] = ""; 

			widgets.rootWidgetMap[["s-Button_7", "555d8318-848f-4b56-a82c-4b71b013f9f1"]] = ["Symbol only", "s-Group_28"]; 

	widgets.descriptionMap[["s-Path_27", "555d8318-848f-4b56-a82c-4b71b013f9f1"]] = ""; 

			widgets.rootWidgetMap[["s-Path_27", "555d8318-848f-4b56-a82c-4b71b013f9f1"]] = ["Symbol only", "s-Group_28"]; 

	widgets.descriptionMap[["s-Path_4", "555d8318-848f-4b56-a82c-4b71b013f9f1"]] = ""; 

			widgets.rootWidgetMap[["s-Path_4", "555d8318-848f-4b56-a82c-4b71b013f9f1"]] = ["Settings", "s-Path_4"]; 

	widgets.descriptionMap[["s-Button_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Button", "s-Button_1"]; 

	widgets.descriptionMap[["s-Button_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Button_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Button", "s-Button_2"]; 

	widgets.descriptionMap[["s-Button_3", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Button_3", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Button", "s-Button_3"]; 

	widgets.descriptionMap[["s-Button_1", "286f34bf-c644-4756-9153-e492441420e9"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "286f34bf-c644-4756-9153-e492441420e9"]] = ["Button", "s-Button_1"]; 

	widgets.descriptionMap[["s-Button_4", "286f34bf-c644-4756-9153-e492441420e9"]] = ""; 

			widgets.rootWidgetMap[["s-Button_4", "286f34bf-c644-4756-9153-e492441420e9"]] = ["Symbol only", "s-Group_28"]; 

	widgets.descriptionMap[["s-Path_27", "286f34bf-c644-4756-9153-e492441420e9"]] = ""; 

			widgets.rootWidgetMap[["s-Path_27", "286f34bf-c644-4756-9153-e492441420e9"]] = ["Symbol only", "s-Group_28"]; 

	widgets.descriptionMap[["s-Button_3", "286f34bf-c644-4756-9153-e492441420e9"]] = ""; 

			widgets.rootWidgetMap[["s-Button_3", "286f34bf-c644-4756-9153-e492441420e9"]] = ["Button", "s-Button_3"]; 

	widgets.descriptionMap[["s-Button_6", "286f34bf-c644-4756-9153-e492441420e9"]] = ""; 

			widgets.rootWidgetMap[["s-Button_6", "286f34bf-c644-4756-9153-e492441420e9"]] = ["Button", "s-Button_6"]; 

	widgets.descriptionMap[["s-Button_8", "286f34bf-c644-4756-9153-e492441420e9"]] = ""; 

			widgets.rootWidgetMap[["s-Button_8", "286f34bf-c644-4756-9153-e492441420e9"]] = ["Button", "s-Button_8"]; 

	widgets.descriptionMap[["s-Button_14", "286f34bf-c644-4756-9153-e492441420e9"]] = ""; 

			widgets.rootWidgetMap[["s-Button_14", "286f34bf-c644-4756-9153-e492441420e9"]] = ["Button", "s-Button_14"]; 

	widgets.descriptionMap[["s-Button_16", "286f34bf-c644-4756-9153-e492441420e9"]] = ""; 

			widgets.rootWidgetMap[["s-Button_16", "286f34bf-c644-4756-9153-e492441420e9"]] = ["Button", "s-Button_16"]; 

	widgets.descriptionMap[["s-Button_18", "286f34bf-c644-4756-9153-e492441420e9"]] = ""; 

			widgets.rootWidgetMap[["s-Button_18", "286f34bf-c644-4756-9153-e492441420e9"]] = ["Button", "s-Button_18"]; 

	widgets.descriptionMap[["s-Button_10", "286f34bf-c644-4756-9153-e492441420e9"]] = ""; 

			widgets.rootWidgetMap[["s-Button_10", "286f34bf-c644-4756-9153-e492441420e9"]] = ["Button", "s-Button_10"]; 

	widgets.descriptionMap[["s-Button_12", "286f34bf-c644-4756-9153-e492441420e9"]] = ""; 

			widgets.rootWidgetMap[["s-Button_12", "286f34bf-c644-4756-9153-e492441420e9"]] = ["Button", "s-Button_12"]; 

	widgets.descriptionMap[["s-Button_20", "286f34bf-c644-4756-9153-e492441420e9"]] = ""; 

			widgets.rootWidgetMap[["s-Button_20", "286f34bf-c644-4756-9153-e492441420e9"]] = ["Button", "s-Button_20"]; 

	widgets.descriptionMap[["s-Button_22", "286f34bf-c644-4756-9153-e492441420e9"]] = ""; 

			widgets.rootWidgetMap[["s-Button_22", "286f34bf-c644-4756-9153-e492441420e9"]] = ["Button", "s-Button_22"]; 

	