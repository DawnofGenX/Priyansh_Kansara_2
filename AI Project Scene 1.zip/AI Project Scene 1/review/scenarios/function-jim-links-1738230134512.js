(function(window, undefined) {

  var jimLinks = {
    "32585138-1be8-4c8e-8c33-432d0a9b120e" : {
    },
    "af64949c-5f16-439c-9f2b-bf2896b9945f" : {
    },
    "7fdbe31e-d2d2-4521-a3e1-dfaf18e423be" : {
    },
    "19feb07a-6501-4dbb-ae9d-bdf42021f3f6" : {
      "Button_1" : [
        "af64949c-5f16-439c-9f2b-bf2896b9945f"
      ],
      "Button_2" : [
        "286f34bf-c644-4756-9153-e492441420e9"
      ]
    },
    "555d8318-848f-4b56-a82c-4b71b013f9f1" : {
      "Button_2" : [
        "32585138-1be8-4c8e-8c33-432d0a9b120e"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Button_1" : [
        "555d8318-848f-4b56-a82c-4b71b013f9f1"
      ],
      "Button_2" : [
        "19feb07a-6501-4dbb-ae9d-bdf42021f3f6"
      ],
      "Button_3" : [
        "7fdbe31e-d2d2-4521-a3e1-dfaf18e423be"
      ]
    },
    "286f34bf-c644-4756-9153-e492441420e9" : {
    }    
  }

  window.jimLinks = jimLinks;
})(window);