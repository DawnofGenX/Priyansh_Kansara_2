(function(window, undefined) {
  var dictionary = {
    "32585138-1be8-4c8e-8c33-432d0a9b120e": "Correct_Screen",
    "af64949c-5f16-439c-9f2b-bf2896b9945f": "Leaderboard",
    "7fdbe31e-d2d2-4521-a3e1-dfaf18e423be": "Add_Classroom",
    "19feb07a-6501-4dbb-ae9d-bdf42021f3f6": "Classroom_HomePage_Teacher_Side",
    "555d8318-848f-4b56-a82c-4b71b013f9f1": "Multiple_Question",
    "d12245cc-1680-458d-89dd-4f0d7fb22724": "Classroom",
    "286f34bf-c644-4756-9153-e492441420e9": "View Students",
    "f39803f7-df02-4169-93eb-7547fb8c961a": "Template 1",
    "bb8abf58-f55e-472d-af05-a7d1bb0cc014": "Board 1"
  };

  var uriRE = /^(\/#)?(screens|templates|masters|scenarios)\/(.*)(\.html)?/;
  window.lookUpURL = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, url;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      url = folder + "/" + canvas;
    }
    return url;
  };

  window.lookUpName = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, canvasName;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      canvasName = dictionary[canvas];
    }
    return canvasName;
  };
})(window);