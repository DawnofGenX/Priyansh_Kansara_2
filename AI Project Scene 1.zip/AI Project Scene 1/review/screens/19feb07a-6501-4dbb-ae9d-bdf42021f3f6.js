var content='<div class="ui-page " deviceName="iphone16promax" deviceType="mobile" deviceWidth="440" deviceHeight="956">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS iphone-device canvas firer commentable non-processed" alignment="left" name="Template 1"width="440" height="956">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/templates/f39803f7-df02-4169-93eb-7547fb8c961a/style-1738230134512.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-19feb07a-6501-4dbb-ae9d-bdf42021f3f6" class="screen growth-vertical devMobile devIOS iphone-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Classroom_HomePage_Teacher_Side"width="440" height="956">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/screens/19feb07a-6501-4dbb-ae9d-bdf42021f3f6/style-1738230134512.css" />\
      <link type="text/css" rel="stylesheet" href="./review/screens/19feb07a-6501-4dbb-ae9d-bdf42021f3f6/fonts-1738230134512.css" />\
      <div class="freeLayout">\
      <div id="s-Button_1" class="button multiline manualfit firer click commentable non-processed" customid="Filled button"   datasizewidth="355.27px" datasizeheight="57.25px" dataX="42.98" dataY="125.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_1_0">View LeaderBoard</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_2" class="button multiline manualfit firer click commentable non-processed" customid="Filled button"   datasizewidth="355.27px" datasizeheight="57.25px" dataX="41.75" dataY="210.88" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_2_0">View Students</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_3" class="button multiline manualfit firer click commentable non-processed" customid="Filled button"   datasizewidth="355.27px" datasizeheight="57.25px" dataX="42.36" dataY="461.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_3_0">Classcode : pieonefpqi</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Group_28" class="group firer ie-background commentable non-processed" customid="Symbol only button" datasizewidth="157.00px" datasizeheight="44.00px" >\
        <div id="s-Button_4" class="button multiline manualfit firer click commentable non-processed" customid="Button"   datasizewidth="50.00px" datasizeheight="50.00px" dataX="17.98" dataY="881.11" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Button_4_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Path_27" class="path firer click commentable non-processed" customid="Play icon"   datasizewidth="12.55px" datasizeheight="14.05px" dataX="38.98" dataY="898.97"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="12.550798416137695" height="14.053009033203125" viewBox="38.97508591065298 898.9744320390239 12.550798416137695 14.053009033203125" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_27-19feb" d="M39.97118538269888 913.027441072227 C39.66678589234243 913.027441072227 39.42328613648306 912.9164333817973 39.24068611512075 912.6954403398051 C39.063584979866846 912.4794369218364 38.97508591065298 912.1914425370708 38.97508591065298 911.8324337480083 L38.97508591065298 900.1614284989848 C38.97508591065298 899.8014431474223 39.063584979866846 899.5134335038676 39.24068611512075 899.2974300858989 C39.42328613648306 899.0824337480083 39.66678589234243 898.9744320390239 39.97118538269888 898.9744320390239 C40.137185748909815 898.9744320390239 40.29488533387075 899.0044308183208 40.44428604493032 899.0654354569926 C40.5937859381188 899.120443391563 40.75148552307974 899.1954403398051 40.917485889290674 899.2894344804301 L50.59618538269888 904.892431306602 C50.94478577027212 905.0914364335551 51.185485538338526 905.2714291093364 51.318383869027 905.4324398515239 C51.45668571839224 905.5874386308208 51.525884326790674 905.7754421708598 51.525884326790674 905.996435212852 C51.525884326790674 906.2174282548442 51.45668571839224 906.4084377763286 51.318383869027 906.569433259727 C51.185485538338526 906.7244320390239 50.94478577027212 906.9044399735942 50.59618538269888 907.1084347245708 L40.917485889290674 912.7034359452739 C40.75148552307974 912.8034420487895 40.5937859381188 912.8804378983989 40.44428604493032 912.9364376542583 C40.29488533387075 912.996435212852 40.137185748909815 913.027441072227 39.97118538269888 913.027441072227 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_27-19feb" fill="#FFFFFF" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Button_5" class="button multiline manualfit firer click commentable non-processed" customid="Filled button"   datasizewidth="355.27px" datasizeheight="57.25px" dataX="42.36" dataY="294.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_5_0">Add/Remove Questions</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_6" class="button multiline manualfit firer click commentable non-processed" customid="Filled button"   datasizewidth="355.27px" datasizeheight="57.25px" dataX="42.36" dataY="375.75" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_6_0">Quiz Setting</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;