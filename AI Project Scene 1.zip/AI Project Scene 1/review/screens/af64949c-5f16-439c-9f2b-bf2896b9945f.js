var content='<div class="ui-page " deviceName="iphone16promax" deviceType="mobile" deviceWidth="440" deviceHeight="956">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS iphone-device canvas firer commentable non-processed" alignment="left" name="Template 1"width="440" height="956">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/templates/f39803f7-df02-4169-93eb-7547fb8c961a/style-1738230134512.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-af64949c-5f16-439c-9f2b-bf2896b9945f" class="screen growth-vertical devMobile devIOS iphone-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Leaderboard"width="440" height="956">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/screens/af64949c-5f16-439c-9f2b-bf2896b9945f/style-1738230134512.css" />\
      <link type="text/css" rel="stylesheet" href="./review/screens/af64949c-5f16-439c-9f2b-bf2896b9945f/fonts-1738230134512.css" />\
      <div class="freeLayout">\
      <div id="s-Button_1" class="button multiline manualfit firer click commentable non-processed" customid="Filled button"   datasizewidth="256.27px" datasizeheight="50.00px" dataX="30.49" dataY="108.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_1_0">Student Name</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Subtraction_5" class="path firer click commentable hidden non-processed" customid="Cancel icon"   datasizewidth="18.00px" datasizeheight="18.00px" dataX="372.49" dataY="212.07"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="18.0" height="17.999819967310998" viewBox="372.4925684878392 212.0743987073731 18.0 17.999819967310998" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Subtraction_5-af649" d="M378.7505083906597 217.9150615994889 C378.85070769476005 217.9150615994889 378.95098190489404 217.95306836450385 379.0274110277079 218.029168894977 L381.4896971911439 220.485999265919 L383.9575264010563 218.029168894977 C384.0338806178366 217.95314293631233 384.13405495325935 217.91513617129732 384.234229288682 217.91513617129732 C384.33437865542675 217.91513617129732 384.4345280221716 217.95314293631233 384.51090720762977 218.029168894977 C384.6630912989561 218.18067395237824 384.6636406098681 218.42802864084413 384.51090720762977 218.58008055817356 L382.04252868680516 221.03745778904383 L384.5048398189189 223.49538187984234 C384.65699894156745 223.64688693724358 384.65757322115735 223.89424162570936 384.504265539329 224.04574668311056 C384.427886353871 224.12177264177538 384.3277369871261 224.15977940679034 384.22758762038126 224.15977940679034 C384.1274132849586 224.15977940679034 384.02723894953596 224.12177264177538 383.9508847327557 224.04574668311056 L381.48914788023177 221.58836945224036 L379.0274110277079 224.03913464943236 C378.95110674828317 224.1150860362887 378.8509074441828 224.1529685149564 378.75078304611566 224.1529685149564 C378.65045889862625 224.1529685149564 378.55018468849215 224.11494932130668 378.47403022113457 224.03913464943236 C378.32129681889614 223.88708273210293 378.32129681889614 223.64027490356537 378.47403022113457 223.48822298623583 L380.93631638457055 221.03691092911555 L378.47345594154444 218.57953369824529 C378.32129681889614 218.42693492098758 378.32129681889614 218.18011466381526 378.47457953204656 218.02862203504876 C378.55060915601507 217.95293164952184 378.65050883598167 217.9150615994889 378.7505083906597 217.9150615994889 Z M381.49259355777116 212.0743987073731 C376.5430775217548 212.0743987073731 372.4704864195319 216.14217899793067 372.4926586054379 221.0743086910286 C372.4705613255652 225.9894857263501 376.5151126025939 230.05215784803218 381.45231908044406 230.074131674241 C381.46575222911235 230.07419381741462 381.4791604091029 230.0742186746841 381.49256858909337 230.0742186746841 C386.442059656432 230.0742186746841 390.5146257899772 226.0064259554918 390.49247857274884 221.0743086910286 C390.5145508839437 216.15913165570714 386.4700245755929 212.0964719626598 381.53281809774273 212.07448570781625 C381.5194099177521 212.07442356464256 381.5060017377618 212.0743987073731 381.49259355777116 212.0743987073731 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Subtraction_5-af649" fill="#8E8E93" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Group_28" class="group firer ie-background commentable non-processed" customid="Symbol only button" datasizewidth="157.00px" datasizeheight="44.00px" >\
        <div id="s-Button_4" class="button multiline manualfit firer click commentable non-processed" customid="Button"   datasizewidth="50.00px" datasizeheight="50.00px" dataX="17.36" dataY="881.72" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Button_4_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Path_27" class="path firer click commentable non-processed" customid="Play icon"   datasizewidth="12.55px" datasizeheight="14.05px" dataX="38.36" dataY="899.58"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="12.550798416137695" height="14.053009033203125" viewBox="38.36254295532649 899.5811614153838 12.550798416137695 14.053009033203125" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_27-af649" d="M39.35864242737239 913.6341704485869 C39.05424293701594 913.6341704485869 38.81074318115657 913.5231627581572 38.62814315979426 913.302169716165 C38.45104202454036 913.0861662981963 38.36254295532649 912.7981719134307 38.36254295532649 912.4391631243682 L38.36254295532649 900.7681578753447 C38.36254295532649 900.4081725237822 38.45104202454036 900.1201628802276 38.62814315979426 899.9041594622588 C38.81074318115657 899.6891631243682 39.05424293701594 899.5811614153838 39.35864242737239 899.5811614153838 C39.524642793583325 899.5811614153838 39.68234237854426 899.6111601946807 39.83174308960383 899.6721648333526 C39.98124298279231 899.7271727679229 40.13894256775325 899.802169716165 40.304942933964185 899.89616385679 L49.98364242737239 905.4991606829619 C50.33224281494563 905.698165809915 50.572942583012036 905.8781584856963 50.70584091370051 906.0391692278838 C50.84414276306575 906.1941680071807 50.913341371464185 906.3821715472197 50.913341371464185 906.6031645892119 C50.913341371464185 906.8241576312041 50.84414276306575 907.0151671526885 50.70584091370051 907.1761626360869 C50.572942583012036 907.3311614153838 50.33224281494563 907.5111693499541 49.98364242737239 907.7151641009307 L40.304942933964185 913.3101653216338 C40.13894256775325 913.4101714251494 39.98124298279231 913.4871672747588 39.83174308960383 913.5431670306182 C39.68234237854426 913.6031645892119 39.524642793583325 913.6341704485869 39.35864242737239 913.6341704485869 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_27-af649" fill="#FFFFFF" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Button_2" class="button multiline manualfit firer click commentable non-processed" customid="Filled button"   datasizewidth="102.00px" datasizeheight="50.00px" dataX="307.51" dataY="108.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_2_0">1000</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_3" class="button multiline manualfit firer click commentable non-processed" customid="Filled button"   datasizewidth="256.27px" datasizeheight="50.00px" dataX="30.49" dataY="332.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_3_0">Student Name</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_5" class="button multiline manualfit firer click commentable non-processed" customid="Filled button"   datasizewidth="102.00px" datasizeheight="50.00px" dataX="307.51" dataY="332.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_5_0">1000</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_6" class="button multiline manualfit firer click commentable non-processed" customid="Filled button"   datasizewidth="256.27px" datasizeheight="50.00px" dataX="30.49" dataY="256.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_6_0">Student Name</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_7" class="button multiline manualfit firer click commentable non-processed" customid="Filled button"   datasizewidth="102.00px" datasizeheight="50.00px" dataX="307.51" dataY="256.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_7_0">1000</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_8" class="button multiline manualfit firer click commentable non-processed" customid="Filled button"   datasizewidth="256.27px" datasizeheight="50.00px" dataX="30.49" dataY="180.07" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_8_0">Student Name</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_9" class="button multiline manualfit firer click commentable non-processed" customid="Filled button"   datasizewidth="102.00px" datasizeheight="50.00px" dataX="307.51" dataY="180.07" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_9_0">1000</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_14" class="button multiline manualfit firer click commentable non-processed" customid="Filled button"   datasizewidth="256.27px" datasizeheight="50.00px" dataX="30.49" dataY="822.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_14_0">Student Name</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_15" class="button multiline manualfit firer click commentable non-processed" customid="Filled button"   datasizewidth="102.00px" datasizeheight="50.00px" dataX="307.51" dataY="822.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_15_0">1000</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_16" class="button multiline manualfit firer click commentable non-processed" customid="Filled button"   datasizewidth="256.27px" datasizeheight="50.00px" dataX="30.49" dataY="469.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_16_0">Student Name</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_17" class="button multiline manualfit firer click commentable non-processed" customid="Filled button"   datasizewidth="102.00px" datasizeheight="50.00px" dataX="307.51" dataY="469.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_17_0">1000</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_18" class="button multiline manualfit firer click commentable non-processed" customid="Filled button"   datasizewidth="256.27px" datasizeheight="50.00px" dataX="30.49" dataY="401.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_18_0">Student Name</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_19" class="button multiline manualfit firer click commentable non-processed" customid="Filled button"   datasizewidth="102.00px" datasizeheight="50.00px" dataX="307.51" dataY="401.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_19_0">1000</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_10" class="button multiline manualfit firer click commentable non-processed" customid="Filled button"   datasizewidth="256.27px" datasizeheight="50.00px" dataX="30.49" dataY="755.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_10_0">Student Name</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_11" class="button multiline manualfit firer click commentable non-processed" customid="Filled button"   datasizewidth="102.00px" datasizeheight="50.00px" dataX="307.51" dataY="755.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_11_0">1000</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_12" class="button multiline manualfit firer click commentable non-processed" customid="Filled button"   datasizewidth="256.27px" datasizeheight="50.00px" dataX="30.49" dataY="680.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_12_0">Student Name</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_13" class="button multiline manualfit firer click commentable non-processed" customid="Filled button"   datasizewidth="102.00px" datasizeheight="50.00px" dataX="307.51" dataY="680.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_13_0">1000</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_20" class="button multiline manualfit firer click commentable non-processed" customid="Filled button"   datasizewidth="256.27px" datasizeheight="50.00px" dataX="30.49" dataY="611.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_20_0">Student Name</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_21" class="button multiline manualfit firer click commentable non-processed" customid="Filled button"   datasizewidth="102.00px" datasizeheight="50.00px" dataX="307.51" dataY="611.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_21_0">1000</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_22" class="button multiline manualfit firer click commentable non-processed" customid="Filled button"   datasizewidth="256.27px" datasizeheight="50.00px" dataX="30.49" dataY="539.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_22_0">Student Name</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_23" class="button multiline manualfit firer click commentable non-processed" customid="Filled button"   datasizewidth="102.00px" datasizeheight="50.00px" dataX="307.51" dataY="539.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_23_0">1000</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;